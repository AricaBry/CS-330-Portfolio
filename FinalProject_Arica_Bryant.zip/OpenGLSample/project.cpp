// Arica N. Bryant
// 11/30/2023
// CS-330 Comp Graphics and Visualiaztion
// Starter Code used: tut_05_03.cpp tutorial code by SNHU
//                    Vertex and Fragment Source Shaders by learn.OpenGL
//                    UCreatePlaneMesh() by Brian Battersby - SNHU Instructor / Computer Science
//                    UCreateCubeMesh() by learn.OpenGL

#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <glad/glad.h>       // GLAD library
#include <GLFW/glfw3.h>     // GLFW library

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <vector>
#include "shader.h"
#include "camera.h" // Camera class

using namespace std; // Standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
    const char* const WINDOW_TITLE = "Final Project"; // Macro for window title

    // Variables for window width and height
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;

    // Stores the GL data relative to a given mesh
    struct GLMesh
    {
        GLuint vao;         // Handle for the vertex array object
        GLuint vbos[2];     // Handles for the vertex buffer objects
        GLuint nIndices;    // Number of indices of the mesh
        GLuint nVertices;    // Number of vertices of the mesh
    };

    // Main GLFW window
    GLFWwindow* gWindow = nullptr;

    // Meshes
    GLMesh gPlaneMesh; // Plane mesh data
    GLMesh gPrismMesh; // Prism mesh data
    GLMesh gPyramidMesh; // Pyramid mesh data
    GLMesh gCubeMesh; // Cube mesh data

    // Shader programs
    GLuint gShader;
    GLuint gLightBlockId;

    // Textures
    GLuint pyramidTextureId; // Pencil Head Texture id
    GLuint planeTextureId; // Plane Texture id
    GLuint pbodyTextureId; // Pencil body Texture id
    GLuint stickyNoteTextureId; // Sticky note texture id
    GLuint boxTextureId; // Box texture id
    GLuint pagesTextureId; // Pages texture id
    GLuint bookFCoverTextureId; // Texture for front cover of book
    GLuint bookSCoverTextureId; // Texture for side cover of book

    // camera
    Camera gCamera(glm::vec3(0.0f, 7.0f, 40.0f));
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    // timing
    float gDeltaTime = 0.0f; // time between current frame and last frame
    float gLastFrame = 0.0f;

    // view
    bool perspectiveView = true;

    // First light position and scale
    glm::vec3 gLightPosition(-4.0f, 4.0, -3.0f);
    glm::vec3 gLightScale(0.3f);
    glm::vec4 gLightColor(1.00, 0.95, 0.03, 1.0); // yellow

    // Second light position and scale
    glm::vec3 gLightPosition2(7.0f, 4.0, 2.0f);
    glm::vec4 gLightColor2(1.0f, 1.0f, 1.0f, 1.0f); // white

    // Third light position and scale
    glm::vec3 gLightPosition3(1.0f, 3.0, 6.0f);
    glm::vec4 gLightColor3(1.0f, 1.0f, 1.0f, 1.0f); // white
}

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void UCreatePlane(GLMesh& mesh);
void UCreatePrism(GLMesh& mesh);
void UCreatePyramid(GLMesh& mesh);
void UCreateCube(GLMesh& mesh);
void UDestroyMesh(GLMesh& mesh);
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);


/* Lighting Vertex Shader Source Code*/ // learn.OpenGL // Edited to accomodate light color
const GLchar* vertexShaderSource = GLSL(440,
    layout(location = 0) in vec3 aPos;
    layout(location = 1) in vec3 aNormal;
    layout(location = 2) in vec2 aTexCoords;

    out vec3 FragPos;
    out vec3 Normal;
    out vec2 TexCoords;

    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main()
    {
        FragPos = vec3(model * vec4(aPos, 1.0));
        Normal = mat3(transpose(inverse(model))) * aNormal;
        TexCoords = aTexCoords;

        gl_Position = projection * view * vec4(FragPos, 1.0);
    }
);

/* Lighting Fragment Shader Source Code*/ // learn.OpenGL // Edited to accomodate light color
const GLchar* fragmentShaderSource = GLSL(440,
    out vec4 FragColor;

    struct Material {
        sampler2D uTexture;
        float shininess;
    };

    struct DirLight {
        vec3 direction;

        vec3 ambient;
        vec3 diffuse;
        vec3 specular;
        vec3 lightColor;
    };

    struct PointLight {
        vec3 position;

        float constant;
        float linear;
        float quadratic;

        vec3 ambient;
        vec3 diffuse;
        vec3 specular;
        vec3 lightColor;
    };

    struct SpotLight {
        vec3 position;
        vec3 direction;
        float cutOff;
        float outerCutOff;

        float constant;
        float linear;
        float quadratic;

        vec3 ambient;
        vec3 diffuse;
        vec3 specular;
        vec3 lightColor;
    };

    in vec3 FragPos;
    in vec3 Normal;
    in vec2 TexCoords;

    uniform vec3 viewPos;
    uniform DirLight dirLight;
    uniform PointLight pointLights[4];
    uniform SpotLight spotLight;
    uniform Material material;

    // function prototypes
    vec3 CalcDirLight(DirLight light, vec3 normal, vec3 viewDir);
    vec3 CalcPointLight(PointLight light, vec3 normal, vec3 fragPos, vec3 viewDir);
    vec3 CalcSpotLight(SpotLight light, vec3 normal, vec3 fragPos, vec3 viewDir);

    void main()
    {
        // properties
        vec3 norm = normalize(Normal);
        vec3 viewDir = normalize(viewPos - FragPos);

        // == =====================================================
        // Our lighting is set up in 3 phases: directional, point lights and an optional flashlight
        // For each phase, a calculate function is defined that calculates the corresponding color
        // per lamp. In the main() function we take all the calculated colors and sum them up for
        // this fragment's final color.
        // == =====================================================
        // phase 1: directional lighting
        vec3 result = CalcDirLight(dirLight, norm, viewDir);
        // phase 2: point lights
        for (int i = 0; i < 4; i++) { // Edit for point lights
            result += CalcPointLight(pointLights[i], norm, FragPos, viewDir);
        }
        // phase 3: spot light
         result += CalcSpotLight(spotLight, norm, FragPos, viewDir);

        FragColor = vec4(result, 1.0);
    }

    // calculates the color when using a directional light.
    vec3 CalcDirLight(DirLight light, vec3 normal, vec3 viewDir)
    {
        vec3 lightDir = normalize(-light.direction);
        // diffuse shading
        float diff = max(dot(normal, lightDir), 0.0);
        // specular shading
        vec3 reflectDir = reflect(-lightDir, normal);
        float spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);
        // combine results
        vec3 ambient = light.ambient * light.lightColor * vec3(texture(material.uTexture, TexCoords));
        vec3 diffuse = light.diffuse * light.lightColor * diff * vec3(texture(material.uTexture, TexCoords));
        vec3 specular = light.specular * light.lightColor * spec * vec3(texture(material.uTexture, TexCoords));
        return (ambient + diffuse + specular);
    }

    // calculates the color when using a point light.
    vec3 CalcPointLight(PointLight light, vec3 normal, vec3 fragPos, vec3 viewDir)
    {
        vec3 lightDir = normalize(light.position - fragPos);
        // diffuse shading
        float diff = max(dot(normal, lightDir), 0.0);
        // specular shading
        vec3 reflectDir = reflect(-lightDir, normal);
        float spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);
        // attenuation
        float distance = length(light.position - fragPos);
        float attenuation = 1.0 / (light.constant + light.linear * distance + light.quadratic * (distance * distance));
        // combine results
        vec3 ambient = light.ambient * light.lightColor * vec3(texture(material.uTexture, TexCoords));
        vec3 diffuse = light.diffuse * diff * light.lightColor * vec3(texture(material.uTexture, TexCoords)); // UPDATED
        vec3 specular = light.specular * spec * light.lightColor * vec3(texture(material.uTexture, TexCoords));
        ambient *= attenuation;
        diffuse *= attenuation;
        specular *= attenuation;
        return (ambient + diffuse + specular);
    }

    // calculates the color when using a spot light.
    vec3 CalcSpotLight(SpotLight light, vec3 normal, vec3 fragPos, vec3 viewDir)
    {
        vec3 lightDir = normalize(light.position - fragPos);
        // diffuse shading
        float diff = max(dot(normal, lightDir), 0.0);
        // specular shading
        vec3 reflectDir = reflect(-lightDir, normal);
        float spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);
        // attenuation
        float distance = length(light.position - fragPos);
        float attenuation = 1.0 / (light.constant + light.linear * distance + light.quadratic * (distance * distance));
        // spotlight intensity
        float theta = dot(lightDir, normalize(-light.direction));
        float epsilon = light.cutOff - light.outerCutOff;
        float intensity = clamp((theta - light.outerCutOff) / epsilon, 0.0, 1.0);
        // combine results
        vec3 ambient = light.ambient * light.lightColor * vec3(texture(material.uTexture, TexCoords));
        vec3 diffuse = light.diffuse * light.lightColor * diff * vec3(texture(material.uTexture, TexCoords));
        vec3 specular = light.specular * light.lightColor * spec * vec3(texture(material.uTexture, TexCoords));
        ambient *= attenuation * intensity;
        diffuse *= attenuation * intensity;
        specular *= attenuation * intensity;
        return (ambient + diffuse + specular);
    }
);


/* Light Object Vertex Shader Source Code*/
const GLchar* lightVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data

    //Uniform / Global variables for the  transform matrices
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main()
    {
        gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
    }
);

/* Light Object Fragment Shader Source Code*/
const GLchar* lightFragmentShaderSource = GLSL(440,

    out vec4 fragmentColor; // For outgoing lamp color (smaller cube) to the GPU

void main()
{
    fragmentColor = vec4(1.0f); // Set color to white (1.0f,1.0f,1.0f) with alpha 1.0
}
);

// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so let's flip it
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}


int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // Calls the functions to create the Vertex Buffer Objects
    UCreatePlane(gPlaneMesh);
    UCreatePrism(gPrismMesh);
    UCreatePyramid(gPyramidMesh);
    UCreateCube(gCubeMesh);

    // Create the shader programs
    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gShader))
        return EXIT_FAILURE;

    if (!UCreateShaderProgram(lightVertexShaderSource, lightFragmentShaderSource, gLightBlockId))
        return EXIT_FAILURE;

    // Load textures
    const char* texFilename = "../OpenGLSample/pencilHead.jpg";
    if (!UCreateTexture(texFilename, pyramidTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "../OpenGLSample/pencilBody.jpg";
    if (!UCreateTexture(texFilename, pbodyTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "../OpenGLSample/surfaceTexture.jpg";
    if (!UCreateTexture(texFilename, planeTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "../OpenGLSample/stickyNote.jpg";
    if (!UCreateTexture(texFilename, stickyNoteTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "../OpenGLSample/box.jpg";
    if (!UCreateTexture(texFilename, boxTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "../OpenGLSample/pages.jpg";
    if (!UCreateTexture(texFilename, pagesTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "../OpenGLSample/frontCover.jpg";
    if (!UCreateTexture(texFilename, bookFCoverTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "../OpenGLSample/sideCover.jpg";
    if (!UCreateTexture(texFilename, bookSCoverTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }

    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gShader);

    // We set the texture as texture units
    glUniform1i(glGetUniformLocation(gShader, "headTexture"), 0);
    glUniform1i(glGetUniformLocation(gShader, "bodyTexture"), 1);
    glUniform1i(glGetUniformLocation(gShader, "surfaceTexture"), 2);
    glUniform1i(glGetUniformLocation(gShader, "stickyNoteTexture"), 3);
    glUniform1i(glGetUniformLocation(gShader, "boxTexture"), 4);
    glUniform1i(glGetUniformLocation(gShader, "pagesTexture"), 5);
    glUniform1i(glGetUniformLocation(gShader, "bookCoverTexture"), 6);
    glUniform1i(glGetUniformLocation(gShader, "bookCoverSideTexture"), 7);

    // Sets the background color of the window
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    // render loop
    // -----------
    while (!glfwWindowShouldClose(gWindow))
    {
        // per-frame timing
        // --------------------
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        // input
        // -----
        UProcessInput(gWindow);

        // Render this frame
        URender();

        glfwPollEvents();
    }

    // Release mesh data
    UDestroyMesh(gPlaneMesh);
    UDestroyMesh(gPrismMesh);
    UDestroyMesh(gPyramidMesh);
    UDestroyMesh(gCubeMesh);

    // Release texture
    UDestroyTexture(pyramidTextureId);
    UDestroyTexture(pbodyTextureId);
    UDestroyTexture(planeTextureId);
    UDestroyTexture(stickyNoteTextureId);
    UDestroyTexture(boxTextureId);
    UDestroyTexture(pagesTextureId);
    UDestroyTexture(bookFCoverTextureId);
    UDestroyTexture(bookSCoverTextureId);

    // Release shader program
    UDestroyShaderProgram(gShader);
    UDestroyShaderProgram(gLightBlockId);

    exit(EXIT_SUCCESS); // Terminates the program successfully
}


// Initialize GLFW, GLAD, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // glad: load all OpenGL function pointers
// ---------------------------------------
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}


// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
    static const float cameraSpeed = 2.5f;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.ProcessKeyboard(UP, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);

    // Switches camera mode
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS && !perspectiveView) {
        perspectiveView = true;
    }
        
    else if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS && perspectiveView) {
        perspectiveView = false;
    }
}


// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);
}

// glfw: handle mouse button events
// --------------------------------
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
    case GLFW_MOUSE_BUTTON_LEFT:
    {
        if (action == GLFW_PRESS)
            cout << "Left mouse button pressed" << endl;
        else
            cout << "Left mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_MIDDLE:
    {
        if (action == GLFW_PRESS)
            cout << "Middle mouse button pressed" << endl;
        else
            cout << "Middle mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_RIGHT:
    {
        if (action == GLFW_PRESS)
            cout << "Right mouse button pressed" << endl;
        else
            cout << "Right mouse button released" << endl;
    }
    break;

    default:
        cout << "Unhandled mouse button event" << endl;
        break;
    }
}

// Functioned called to render a frame
void URender()
{
    // Declarations
    const glm::vec3 cameraPosition = gCamera.Position;
    glm::vec2 uvScale(1.0f, 1.0f);
    glm::mat4 view,
        projection,
        scale,
        rotation,
        pyrRotation2,
        prismRotation2,
        translation,
        model;

    GLint modelLoc,
        viewLoc,
        projLoc,
        viewPositionLoc;

    // Enable z-depth
    glEnable(GL_DEPTH_TEST);

    // Clear the frame and z buffers
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    if (perspectiveView == true) {
        // camera/view transformation
        view = gCamera.GetViewMatrix();
        // Creates a perspective projection
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }
    if (perspectiveView == false) {
        // camera/view transformation
        view = gCamera.GetViewMatrix();
        // Create a orthogonigal projection
        projection = glm::ortho(-20.0f, 20.0f, -20.f, 20.0f, 0.1f, 100.0f);
    }

    // Draw the plane/surface -------------------------------------------
// Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gPlaneMesh.vao);

    // 1. Scales the object
    scale = glm::scale(glm::vec3(15.0f, 15.0f, 12.0f));
    // 2. Place object
    translation = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * scale;

    // Set the shader to be used
    glUseProgram(gShader);

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gShader, "model");
    viewLoc = glGetUniformLocation(gShader, "view");
    projLoc = glGetUniformLocation(gShader, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Lighting
    viewPositionLoc = glGetUniformLocation(gShader, "viewPos");
    // Directional Light
    GLuint dirLightDirLoc = glGetUniformLocation(gShader, "dirLight.direction");
    GLuint dirLightAmbLoc = glGetUniformLocation(gShader, "dirLight.ambient");
    GLuint dirLightDiffLoc = glGetUniformLocation(gShader, "dirLight.diffuse");
    GLuint dirLightSpecLoc = glGetUniformLocation(gShader, "dirLight.specular");
    GLuint dirColorLoc = glGetUniformLocation(gShader, "dirLight.lightColor");

    // Point Light 1
    GLuint pointPositionLoc = glGetUniformLocation(gShader, "pointLights[0].position");
    GLuint pointAmbLoc = glGetUniformLocation(gShader, "pointLights[0].ambient");
    GLuint pointDiffLoc = glGetUniformLocation(gShader, "pointLights[0].diffuse");
    GLuint pointSpecLoc = glGetUniformLocation(gShader, "pointLights[0].specular");
    GLuint pointConstLoc = glGetUniformLocation(gShader, "pointLights[0].constant");
    GLuint pointLinLoc = glGetUniformLocation(gShader, "pointLights[0].linear");
    GLuint pointQuadLoc = glGetUniformLocation(gShader, "pointLights[0].quadratic");
    GLuint pointColorLoc = glGetUniformLocation(gShader, "pointLights[0].lightColor");

    // Point Light 2
    GLuint pointPositionLoc2 = glGetUniformLocation(gShader, "pointLights[1].position");
    GLuint pointAmbLoc2 = glGetUniformLocation(gShader, "pointLights[1].ambient");
    GLuint pointDiffLoc2 = glGetUniformLocation(gShader, "pointLights[1].diffuse");
    GLuint pointSpecLoc2 = glGetUniformLocation(gShader, "pointLights[1].specular");
    GLuint pointConstLoc2 = glGetUniformLocation(gShader, "pointLights[1].constant");
    GLuint pointLinLoc2 = glGetUniformLocation(gShader, "pointLights[1].linear");
    GLuint pointQuadLoc2 = glGetUniformLocation(gShader, "pointLights[1].quadratic");
    GLuint pointColorLoc2 = glGetUniformLocation(gShader, "pointLights[1].lightColor");

    // Point Light 3
    GLuint pointPositionLoc3 = glGetUniformLocation(gShader, "pointLights[2].position");
    GLuint pointAmbLoc3 = glGetUniformLocation(gShader, "pointLights[2].ambient");
    GLuint pointDiffLoc3 = glGetUniformLocation(gShader, "pointLights[2].diffuse");
    GLuint pointSpecLoc3 = glGetUniformLocation(gShader, "pointLights[2].specular");
    GLuint pointConstLoc3 = glGetUniformLocation(gShader, "pointLights[2].constant");
    GLuint pointLinLoc3 = glGetUniformLocation(gShader, "pointLights[2].linear");
    GLuint pointQuadLoc3 = glGetUniformLocation(gShader, "pointLights[2].quadratic");
    GLuint pointColorLoc3 = glGetUniformLocation(gShader, "pointLights[2].lightColor");

    // Point Light 4
    GLuint pointPositionLoc4 = glGetUniformLocation(gShader, "pointLights[3].position");
    GLuint pointAmbLoc4 = glGetUniformLocation(gShader, "pointLights[3].ambient");
    GLuint pointDiffLoc4 = glGetUniformLocation(gShader, "pointLights[3].diffuse");
    GLuint pointSpecLoc4 = glGetUniformLocation(gShader, "pointLights[3].specular");
    GLuint pointConstLoc4 = glGetUniformLocation(gShader, "pointLights[3].constant");
    GLuint pointLinLoc4 = glGetUniformLocation(gShader, "pointLights[3].linear");
    GLuint pointQuadLoc4 = glGetUniformLocation(gShader, "pointLights[3].quadratic");
    GLuint pointColorLoc4 = glGetUniformLocation(gShader, "pointLights[3].lightColor");

    // Spotlight
    GLuint spotPositionLoc = glGetUniformLocation(gShader, "spotLight.position");
    GLuint spotDirLoc = glGetUniformLocation(gShader, "spotLightt.direction");
    GLuint spotAmbLoc = glGetUniformLocation(gShader, "spotLight.ambient");
    GLuint spotDiffLoc = glGetUniformLocation(gShader, "spotLight.diffuse");
    GLuint spotSpecLoc = glGetUniformLocation(gShader, "spotLight.specular");
    GLuint spotConstLoc = glGetUniformLocation(gShader, "spotLight.constant");
    GLuint spotLinLoc = glGetUniformLocation(gShader, "spotLight.linear");
    GLuint spotQuadLoc = glGetUniformLocation(gShader, "spotLight.quadratic");
    GLuint spotCutOffLoc = glGetUniformLocation(gShader, "spotLight.cutOff");
    GLuint spotOuterCutLoc = glGetUniformLocation(gShader, "spotLight.outerCutOff");
    GLuint spotColorLoc = glGetUniformLocation(gShader, "spotlight.lightColor");


    GLuint materialDiffLoc = glGetUniformLocation(gShader, "material.uTexture");
    GLuint materialShineLoc = glGetUniformLocation(gShader, "material.shininess");

    glUniform1i(materialDiffLoc, 0);
    glUniform1f(materialShineLoc, 32.0f);

    // Directional Light
    glUniform3f(dirLightDirLoc, -0.2f, -1.0f, -0.3f);
    glUniform3f(dirLightAmbLoc, 0.15f, 0.15f, 0.15f);
    glUniform3f(dirLightDiffLoc, 0.5f, 0.5f, 0.5f);
    glUniform3f(dirLightSpecLoc, 0.5f, 0.5f, 0.5);
    glUniform3f(dirColorLoc, gLightColor2.x, gLightColor2.y, gLightColor2.z);

    // Point Light 1
    glUniform3f(pointPositionLoc, gLightPosition.x, gLightPosition.y, gLightPosition.z);
    glUniform3f(pointAmbLoc, 0.2f, 0.2f, 0.2f);
    glUniform3f(pointDiffLoc, 0.8f, 0.8f, 0.8f);
    glUniform3f(pointSpecLoc, 10.0f, 10.0f, 10.0f);
    glUniform1f(pointConstLoc, 1.0f);
    glUniform1f(pointLinLoc, 0.09);
    glUniform1f(pointQuadLoc, 0.032);
    glUniform3f(pointColorLoc, gLightColor.x, gLightColor.y, gLightColor.z);

    // Point Light 2
    glUniform3f(pointPositionLoc2, gLightPosition2.x, gLightPosition2.y, gLightPosition2.z);
    glUniform3f(pointAmbLoc2, 0.2f, 0.2f, 0.2f);
    glUniform3f(pointDiffLoc2, 0.8f, 0.8f, 0.8f);
    glUniform3f(pointSpecLoc2, 1.0f, 1.0f, 1.0f);
    glUniform1f(pointConstLoc2, 1.0f);
    glUniform1f(pointLinLoc2, 0.09);
    glUniform1f(pointQuadLoc2, 0.032);
    glUniform3f(pointColorLoc2, gLightColor2.x, gLightColor2.y, gLightColor2.z);

    // Point Light 3
    glUniform3f(pointPositionLoc3, gLightPosition3.x, gLightPosition3.y, gLightPosition3.z);
    glUniform3f(pointAmbLoc3, 0.50f, 0.50f, 0.50f);
    glUniform3f(pointDiffLoc3, 0.8f, 0.8f, 0.8f);
    glUniform3f(pointSpecLoc3, 0.2f, 0.2f, 0.2f);
    glUniform1f(pointConstLoc3, 1.0f);
    glUniform1f(pointLinLoc3, 0.09);
    glUniform1f(pointQuadLoc3, 0.032);
    glUniform3f(pointColorLoc3, gLightColor3.x, gLightColor3.y, gLightColor3.z);

    // Point Light 4 // Currently off
    glUniform3f(pointPositionLoc4, 0.0f, 0.0f, 0.0f);
    glUniform3f(pointAmbLoc4, 0.0f, 0.0f, 0.0f);
    glUniform3f(pointDiffLoc4, 0.0f, 0.0f, 0.0f);
    glUniform3f(pointSpecLoc4, 0.0f, 0.0f, 0.0f);
    glUniform1f(pointConstLoc4, 1.0f);
    glUniform1f(pointLinLoc4, 0.09);
    glUniform1f(pointQuadLoc4, 0.032);
    glUniform3f(pointColorLoc4, gLightColor.x, gLightColor.y, gLightColor.z);

    // Spotlight // Currently off
    glUniform3f(spotPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);
    glUniform3f(spotAmbLoc, 0.0f, 0.0f, 0.0f);
    glUniform3f(spotDiffLoc, 0.0f, 0.0f, 0.0f);
    glUniform3f(spotSpecLoc, 0.0f, 0.0f, 0.0f);
    glUniform1f(spotConstLoc, 1.0f);
    glUniform1f(spotLinLoc, 0.09);
    glUniform1f(spotQuadLoc, 0.032);
    glUniform1f(spotCutOffLoc, glm::cos(glm::radians(12.5f)));
    glUniform1f(spotOuterCutLoc, glm::cos(glm::radians(15.0f)));
    glUniform3f(spotColorLoc, gLightColor.x, gLightColor.y, gLightColor.z);

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, planeTextureId);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gPlaneMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

    // Draw the prism (pencil body) --------------------------------------------
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gPrismMesh.vao);

    // 1. Scales the object
    scale = glm::scale(glm::vec3(0.2f, 2.0f, 0.2f));
    // 2. Rotates shape on x axis
    rotation = glm::rotate(glm::radians(90.0f), glm::vec3(1.0, 0.0f, 0.0f));
    // Rotates shape on z axis
    prismRotation2 = glm::rotate(glm::radians(20.0f), glm::vec3(0.0, 0.0f, 1.0f));
    // 3. Moves object
    translation = glm::translate(glm::vec3(0.0f, 0.3f, 5.0f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * prismRotation2 * scale;

    // Set the shader to be used
    glUseProgram(gShader);

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gShader, "model");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, pbodyTextureId);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gPrismMesh.nVertices);

    // Draw the pyramid (pencil head) -------------------------------------------
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gPyramidMesh.vao);

    // 1. Scales the object
    scale = glm::scale(glm::vec3(0.4f, 0.3f, 1.0f));
    // 2. Rotates shape
    rotation = glm::rotate(glm::radians(180.0f), glm::vec3(1.0, 0.0f, 0.0f));
    pyrRotation2 = glm::rotate(glm::radians(40.0f), glm::vec3(0.0, 1.0f, 1.0f));
    // 3. Place object at the prism's head
    translation = glm::translate(glm::vec3(0.9f, 0.2f, 2.7f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * pyrRotation2 * scale;

    // Set the shader to be used
    glUseProgram(gShader);

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, pyramidTextureId);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gPyramidMesh.nVertices);

    // Draw the stickynote pad -------------------------------------------
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gCubeMesh.vao);

    // 1. Scales the object
    scale = glm::scale(glm::vec3(3.0f, 0.2f, 3.0f));
    // 2. Rotates shape
    rotation = glm::rotate(glm::radians(0.0f), glm::vec3(0.0, 1.0f, 0.0f));
    // 3. Place object at the prism's head
    translation = glm::translate(glm::vec3(-3.0f, 0.3f, 4.5f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;

    // Set the shader to be used
    glUseProgram(gShader);

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, stickyNoteTextureId);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Draw the white box -------------------------------------------
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gCubeMesh.vao);

    // 1. Scales the object
    scale = glm::scale(glm::vec3(1.5f, 1.0f, 1.5f));
    // 2. Rotates shape
    rotation = glm::rotate(glm::radians(45.0f), glm::vec3(0.0, 1.0f, 0.0f));
    // 3. Place object at the prism's head
    translation = glm::translate(glm::vec3(-1.5f, 0.6f, -1.5f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;

    // Set the shader to be used
    glUseProgram(gShader);

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gShader, "model");
    viewLoc = glGetUniformLocation(gShader, "view");
    projLoc = glGetUniformLocation(gShader, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, boxTextureId);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Draw the book pages -------------------------------------------
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gCubeMesh.vao);

    // 1. Scales the object
    scale = glm::scale(glm::vec3(5.0f, 0.5f, 5.5f));
    // 2. Rotates shape
    rotation = glm::rotate(glm::radians(45.0f), glm::vec3(0.0, 1.0f, 0.0f));
    // 3. Place object at the prism's head
    translation = glm::translate(glm::vec3(5.5f, 0.3f, 1.00f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;

    // Set the shader to be used
    glUseProgram(gShader);

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gShader, "model");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, pagesTextureId);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Draw the book cover -------------------------------------------
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gCubeMesh.vao);

    // 1. Scales the object
    scale = glm::scale(glm::vec3(5.0f, 0.1f, 5.5f));
    // 2. Rotates shape
    rotation = glm::rotate(glm::radians(45.0f), glm::vec3(0.0, 1.0f, 0.0f));
    // 3. Place object at the prism's head
    translation = glm::translate(glm::vec3(5.5f, 0.6f, 1.00f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;

    // Set the shader to be used
    glUseProgram(gShader);

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, bookFCoverTextureId);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Draw the side book cover -------------------------------------------
    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gCubeMesh.vao);

    // 1. Scales the object
    scale = glm::scale(glm::vec3(0.1f, 0.6f, 5.5f));
    // 2. Rotates shape
    rotation = glm::rotate(glm::radians(45.0f), glm::vec3(0.0, 1.0f, 0.0f));
    // 3. Place object at the prism's head
    translation = glm::translate(glm::vec3(3.7f, 0.35f, 2.8f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;

    // Set the shader to be used
    glUseProgram(gShader);

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, bookSCoverTextureId);

    // Draws the triangles
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.
}

// Creates the plane for the world that represents a surface
void UCreatePlane(GLMesh& mesh) {
    // Position and data
    GLfloat verts[] = {
        // Vertex Positions		// Normals			// Texture coords	// Index
        -1.0f, 0.0f, 1.0f,		0.0f, 1.0f, 0.0f,	0.0f, 0.0f,			//0
        1.0f, 0.0f, 1.0f,		0.0f, 1.0f, 0.0f,	1.0f, 0.0f,			//1
        1.0f,  0.0f, -1.0f,		0.0f, 1.0f, 0.0f,	1.0f, 1.0f,			//2
        -1.0f, 0.0f, -1.0f,		0.0f, 1.0f, 0.0f,	0.0f, 1.0f,			//3
    };

    // Index data
    GLuint indices[] = {
        0,1,2,
        0,3,2
    };

    // total float values per each type
    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    // store vertex and index count
    mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));
    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);

    // Generate the VAO for the mesh
    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);	// activate the VAO

    // Create VBOs for the mesh
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends data to the GPU

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]); // Activates the buffer
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Strides between vertex coordinates
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}

// creates a prism
void UCreatePrism(GLMesh& mesh)
{
    // Vertex data
    GLfloat verts[] = {
        // Front face of prism
        // Vertex Positions    // Normals             // Texture Coordinates
        -0.5f, 1.0f, -1.0f,    0.0f, 1.0f, 0.0f,      1.0f, 1.0f, // A
        -1.0f, 1.0f, 0.0f,     0.0f, 1.0f, 0.0f,      0.0f, 0.1f, // F
        0.0f, 1.0f, 0.0f,      0.0f, 1.0f, 0.0f,      0.5f, -1.0f, // M

        0.0f, 1.0f, 0.0f,      0.0f, 1.0f, 0.0f,      0.5f, -1.0f, // M
        0.5f, 1.0f, -1.0f,     0.0f, 1.0f, 0.0f,      1.0f, 1.0f, // B
        -0.5f, 1.0f, -1.0f,    0.0f, 1.0f, 0.0f,      0.0f, 1.0f, // A

        0.5f, 1.0f, -1.0f,     0.0f, -1.0f, 0.0f,     0.0f, 1.0f, // B
        1.0f, 1.0f, 0.0f,      1.0f, 1.0f, 0.0f,      1.0f, 1.0f, // C
        0.0f, 1.0f, 0.0f,      1.0f, 1.0f, 0.0f,      0.5f, -1.0f, // M

        1.0f, 1.0f, 0.0f,      0.0f, -1.0f, 0.0f,      0.0f, 1.0f, // C
        0.5f, 1.0f, 1.0f,      0.0f, -1.0f, 0.0f,      1.0f, 1.0f, // D
        0.0f, 1.0f, 0.0f,      0.0f, -1.0f, 0.0f,      0.5f, -1.0f, // M

        0.5f, 1.0f, 1.0f,      0.0f, -1.0f, 0.0f,     0.0f, 1.0f, // D
        -0.5f, 1.0f, 1.0f,     0.0f, -1.0f, 0.0f,     1.0f, 1.0f, // E
        0.0f, 1.0f, 0.0f,      0.0f, -1.0f, 0.0f,     0.5f, -1.0f, // M

        -0.5f, 1.0f, 1.0f,     0.0f, -1.0f, 0.0f,     0.0f, 1.0f, // E
        -1.0f, 1.0f, 0.0f,     0.0f, -1.0f, 0.0f,     1.0f, 1.0f, // F
        0.0f, 1.0f, 0.0f,      0.0f, -1.0f, 0.0f,     0.5f, -1.0f, // M

        // Back face of prism
        -0.5f, -1.0f, -1.0f,   0.0f, 1.0f, 0.0f,      0.5f, 1.0f, // G
        -1.0f, -1.0f, 0.0f,    0.0f, 1.0f, 0.0f,      0.0f, 0.0f, // L
        0.0f, -1.0f, 0.0f,     0.0f, 1.0f, 0.0f,      1.0f, 0.0f, // N

        0.0f, -1.0f, 0.0f,     0.0f, -1.0f, 0.0f,     1.0f, 0.0f, // N
        -0.5f, -1.0f, -1.0f,   0.0f, -1.0f, 0.0f,     0.0f, 1.0f, // G
        0.5f, -1.0f, -1.0f,    0.0f, -1.0f, 0.0f,     0.0f, 0.0f, // H

        0.5f, -1.0f, -1.0f,    0.0f, -1.0f, 0.0f,     0.0f, 1.0f, // H
        1.0f, -1.0f, 0.0f,     0.0f, -1.0f, 0.0f,     1.0f, 1.0f, // I
        0.0f, -1.0f, 0.0f,     0.0f, -1.0f, 0.0f,     1.0f, 0.0f, // N

        1.0f, -1.0f, 0.0f,     0.0f, -1.0f, 0.0f,     1.0f, 1.0f, // I
        0.5f, -1.0f, 1.0f,     0.0f, -1.0f, 0.0f,     1.0f, 1.0f, // J
        0.0f, -1.0f, 0.0f,     0.0f, -1.0f, 0.0f,     1.0f, 0.0f, // N

        0.5f, -1.0f, 1.0f,     0.0f, -1.0f, 0.0f,     0.0f, 1.0f, // J
        -0.5f, -1.0f, 1.0f,    0.0f, -1.0f, 0.0f,     1.0f, 1.0f, // K
        0.0f, -1.0f, 0.0f,     0.0f, -1.0f, 0.0f,     1.0f, 0.0f, // N

        -0.5f, -1.0f, 1.0f,    0.0f, -1.0f, 0.0f,    0.0f, 1.0f, // E
        -1.0f, -1.0f, 0.0f,    0.0f, -1.0f, 0.0f,    1.0f, 1.0f, // F
        0.0f, -1.0f, 0.0f,     0.0f, -1.0f, 0.0f,    1.0f, 0.0f, // N

        // Connecting the pencil sides
        -0.5f, 1.0f, -1.0f,    0.0f, 0.0f, 1.0f,     1.0f, 1.0f, // A
        -0.5f, -1.0f, -1.0f,   0.0f, 0.0f, 1.0f,     1.0f, 0.0f, // G
        0.5f, -1.0f, -1.0f,    0.0f, 0.0f, 1.0f,     0.0f, 0.0f, // H
        0.5f, -1.0f, -1.0f,    0.0f, 0.0f, 1.0f,     0.0f, 0.0f, // H
        0.5f, 1.0f, -1.0f,     0.0f, 0.0f, 1.0f,     0.0f, 1.0f, // B
        -0.5f, 1.0f, -1.0f,    0.0f, 0.0f, 1.0f,     1.0f, 1.0f, // A

        0.5f, 1.0f, -1.0f,     -2.0f, 0.0f, 1.0f,    1.0f, 1.0f, // B
        0.5f, -1.0f, -1.0f,    -2.0f, 0.0f, 1.0f,    1.0f, 0.0f, // H
        1.0f, -1.0f, 0.0f,     -2.0f, 0.0f, 1.0f,    0.0f, 0.0f, // I
        1.0f, -1.0f, 0.0f,     -2.0f, 0.0f, 1.0f,    0.0f, 0.0f, // I
        1.0f, 1.0f, 0.0f,      -2.0f, 0.0f, 1.0f,    0.0f, 1.0f, // C
        0.5f, 1.0f, -1.0f,     -2.0f, 0.0f, 1.0f,    1.0f, 1.0f, // B

        1.0f, 1.0f, 0.0f,      -2.0f, 0.0f, -1.0f,   1.0f, 1.0f, // C
        1.0f, -1.0f, 0.0f,     -2.0f, 0.0f, -1.0f,   1.0f, 0.0f, // I
        0.5f, -1.0f, 1.0f,     -2.0f, 0.0f, -1.0f,   0.0f, 0.0f, // J
        0.5f, -1.0f, 1.0f,     -2.0f, 0.0f, -1.0f,   0.0f, 0.0f, // J
        0.5f, 1.0f, 1.0f,      -2.0f, 0.0f, -1.0f,   0.0f, 1.0f, // D
        1.0f, 1.0f, 0.0f,      -2.0f, 0.0f, -1.0f,   1.0f, 1.0f, // C

        0.5f, 1.0f, 1.0f,      0.0f, 0.0f, 1.0f,     1.0f, 1.0f, // D
        0.5f, -1.0f, 1.0f,     0.0f, 0.0f, 1.0f,     1.0f, 0.0f, // J
        -0.5f, -1.0f, 1.0f,    0.0f, 0.0f, 1.0f,     0.0f, 0.0f, // K
        -0.5f, -1.0f, 1.0f,    0.0f, 0.0f, 1.0f,     0.0f, 0.0f, // K
        -0.5f, 1.0f, 1.0f,     0.0f, 0.0f, 1.0f,     0.0f, 1.0f, // E
        0.5f, 1.0f, 1.0f,      0.0f, 0.0f, 1.0f,     1.0f, 1.0f, // D

        -0.5f, 1.0f, 1.0f,     2.0f, 0.0f, -1.0f,    1.0f, 1.0f, // E
        -0.5f, -1.0f, 1.0f,    2.0f, 0.0f, -1.0f,    1.0f, 0.0f, // K
        -1.0f, -1.0f, 0.0f,    2.0f, 0.0f, -1.0f,    0.0f, 0.0f, // L
        -0.5f, 1.0f, 1.0f,     2.0f, 0.0f, -1.0f,    1.0f, 1.0f, // E
        -1.0f, 1.0f, 0.0f,     2.0f, 0.0f, -1.0f,    0.0f, 1.0f, // F
        -1.0f, -1.0f, 0.0f,    2.0f, 0.0f, -1.0f,    0.0f, 0.0f, // L

        -1.0f, 1.0f, 0.0f,     2.0f, 0.0f, 1.0f,     1.0f, 1.0f, // F
        -1.0f, -1.0f, 0.0f,    2.0f, 0.0f, 1.0f,     1.0f, 0.0f, // L
        -0.5f, -1.0f, -1.0f,   2.0f, 0.0f, 1.0f,     0.0f, 0.0f, // G
        -1.0f, 1.0f, 0.0f,     2.0f, 0.0f, 1.0f,     1.0f, 1.0f, // F
        -0.5f, 1.0f, -1.0f,    2.0f, 0.0f, 1.0f,     0.0f, 1.0f, // A
        -0.5f, -1.0f, -1.0f,   2.0f, 0.0f, 1.0f,     0.0f, 0.0f, // G
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(1, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}

// Creates a pyramid
void UCreatePyramid(GLMesh& mesh) {
    // Vertex data
    GLfloat verts[] = {
        // Base of the pyramid
        // Vertex Positions         // Normals              // Texture Coordinates
        -0.5f, -0.5f, -0.5f,        0.0f, 0.0f, -1.0f,      0.0f, 0.0f, // A
         0.5f, -0.5f, -0.5f,        0.0f, 0.0f, -1.0f,      1.0f, 0.0f, // B
         0.5f,  0.5f, -0.5f,        0.0f, 0.0f, -1.0f,      1.0f, 1.0f, // C
         0.5f,  0.5f, -0.5f,        0.0f, 0.0f, -1.0f,      1.0f, 1.0f, // C
        -0.5f,  0.5f, -0.5f,        0.0f, 0.0f, -1.0f,      0.0f, 1.0f, // D
        -0.5f, -0.5f, -0.5f,        0.0f, 0.0f, -1.0f,      0.0f, 0.0f, // A

        // First pyramid side
        -0.5f, -0.5f, -0.5f,        0.0f, -1.0f, 0.5f,      0.0f, 0.0f, // A
         0.5f, -0.5f, -0.5f,        0.0f, -1.0f, 0.5f,      1.0f, 0.0f, // B
         0.0f,  0.0f,  0.5f,        0.0f, -1.0f, 0.5f,      0.5f, 1.0f, // E

        // Second pyramid side
        0.5f, -0.5f, -0.5f,         1.0f, 0.0f, 0.5f,       0.0f, 0.0f, // B
        0.5f,  0.5f, -0.5f,         1.0f, 0.0f, 0.5f,       1.0f, 0.0f, // C
        0.0f,  0.0f,  0.5f,         1.0f, 0.0f, 0.5f,       0.5f, 1.0f, // E

        // Third pyramid side
         0.5f, 0.5f, -0.5f,         0.0f, 1.0f, 0.5f,       0.0f, 0.0f, // C
        -0.5f, 0.5f, -0.5f,         0.0f, 1.0f, 0.5f,       1.0f, 0.0f, // D
         0.0f, 0.0f,  0.5f,         0.0f, 1.0f, 0.5f,       0.5f, 1.0f, // E

        // Fourth pyramid side
        -0.5f,  0.5f, -0.5f,        -1.0f, 0.0f, 0.5f,       0.0f, 0.0f, // D
        -0.5f, -0.5f, -0.5f,        -1.0f, 0.0f, 0.5f,       1.0f, 0.0f, // A
         0.0f,  0.0f,  0.5f,        -1.0f, 0.0f, 0.5f,       0.5f, 1.0f, // E
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(1, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}

// Creates a cube
void UCreateCube(GLMesh& mesh) {
    // Vertex data
    float verts[] = {
        // positions          // normals           // texture coords
        -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f,  0.0f,
         0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f,  0.0f,
         0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f,  1.0f,
         0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f,  1.0f,
        -0.5f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f,  1.0f,
        -0.5f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f,  0.0f,

        -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  0.0f,
         0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  0.0f,
         0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  1.0f,
         0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f,  1.0f,
        -0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  1.0f,
        -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f,  0.0f,

        -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.0f,
        -0.5f,  0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  1.0f,
        -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
        -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
        -0.5f, -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  0.0f,  0.0f,
        -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f,  0.0f,

         0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.0f,
         0.5f,  0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  1.0f,
         0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
         0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f,  1.0f,
         0.5f, -0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  0.0f,  0.0f,
         0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f,  0.0f,

        -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f,  1.0f,
         0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  1.0f,  1.0f,
         0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f,  0.0f,
         0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f,  0.0f,
        -0.5f, -0.5f,  0.5f,  0.0f, -1.0f,  0.0f,  0.0f,  0.0f,
        -0.5f, -0.5f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f,  1.0f,

        -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f,  1.0f,
         0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  1.0f,  1.0f,
         0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f,  0.0f,
         0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  1.0f,  0.0f,
        -0.5f,  0.5f,  0.5f,  0.0f,  1.0f,  0.0f,  0.0f,  0.0f,
        -0.5f,  0.5f, -0.5f,  0.0f,  1.0f,  0.0f,  0.0f,  1.0f
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;
    const GLuint floatsPerUV = 2;

    mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(1, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
}


void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(2, mesh.vbos);
}

/*Generate and load the texture*/
bool UCreateTexture(const char* filename, GLuint& textureId)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        return true;
    }

    // Error loading the image
    return false;
}

void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}

// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
}


void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}

